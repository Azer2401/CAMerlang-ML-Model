
CAMerlang - v5 2022-06-08 1:50pm
==============================

This dataset was exported via roboflow.ai on June 8, 2022 at 8:19 AM GMT

It includes 2552 images.
Jerawat are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 160x160 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down


