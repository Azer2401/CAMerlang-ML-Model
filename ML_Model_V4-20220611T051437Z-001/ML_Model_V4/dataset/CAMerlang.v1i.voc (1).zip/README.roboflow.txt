
CAMerlang - v1 2022-05-25 10:10pm
==============================

This dataset was exported via roboflow.ai on May 25, 2022 at 3:12 PM GMT

It includes 1064 images.
Jerawat are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


